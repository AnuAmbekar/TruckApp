# TruckApp
My truck app for SIT305
